package weixin.guanjia.core.entity.common;

/**
 * 按钮的基类
 * 
 * @author 孙海峰
 * @date 2013-08-08
 */
public class Button {
        private String name;

        public String getName() {
                return name;
        }

        public void setName(String name) {
                this.name = name;
        }
}