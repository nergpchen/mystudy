UPDATE jeecg_minidao 
SET age=:jeecgMinidao.age, userName=:jeecgMinidao.userName
WHERE id=:jeecgMinidao.id