package org.jeecgframework.web.system.service;

import org.jeecgframework.core.common.service.CommonService;

/**
 * 
 * @author  张代浩
 *
 */
public interface MenuInitService extends CommonService{
	
	public void initMenu();
}
