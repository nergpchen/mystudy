package org.jeecgframework.web.demo.service.test;

public interface TaskDemoServiceI {
	
	public void work();

}
