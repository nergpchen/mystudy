package org.jeecgframework.core.extend.datasource;

public enum DataSourceType {
	dataSource_jeecg,dataSource_enter,dataSource4,mapdataSource
}
