package org.jeecgframework.core.groovy;

/**
 * ISCPIPT接口
 * 实现这个接口的类就成脚本引擎BEAN,公式里能引用的bean只需实现iscript接口
 * @author zhangdaihao
 *
 */
public abstract interface IScript
{
}