package org.jeecgframework.poi.excel.entity.vo;

/**
 * 基础常量
 * Created by jue on 14-4-21.
 */
public interface PoiBaseConstants {

    public static String  GET = "get";

    public static String  SET = "set";

    public static String  CONVERT_GET = "convertGet";

    public static String  CONVERT_SET = "convertSet";
}
